/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "adc_reg.h"
#include "spi_Reg.h"
#include "pid.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
static PID_TypeDef motor_pid;
volatile uint16_t  g_pid_duty = 0;   /* 供 main.c 读取，用于串口/OLED 显示 */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void Motor_Control_Init(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* =============================================================================
 * Motor_Control_Init
 *   初始化 TIM6（1kHz 定时器）和 PID 参数
 *   在 main() 的初始化段调用一次
 *
 * TIM6 时钟链路：
 *   APB1_CLK = 42MHz，APB1 预分频 ≠ 1 → TIM6_CLK = 84MHz
 *   PSC = 83, ARR = 999 → 84MHz / 84 / 1000 = 1kHz (1ms 周期)
 *
 * PID 初始参数（无编码器阶段，kp=1 ki=0 kd=0 = 直通，输出=setpoint）：
 *   接入反馈后再逐步调节 kp/ki/kd。
 * ============================================================================= */
void Motor_Control_Init(void)
{
    /* ---- TIM6 时钟使能（APB1） ---- */
    RCC->APB1ENR |= RCC_APB1ENR_TIM6EN;

    /* ---- 计数配置 ---- */
    TIM6->PSC = 83;           /* 84MHz / (83+1) = 1MHz       */
    TIM6->ARR = 999;          /* 1MHz / (999+1) = 1kHz       */
    TIM6->CNT = 0;

    /* ---- 使能更新中断 ---- */
    TIM6->DIER |= TIM_DIER_UIE;

    /* ---- NVIC 配置：优先级 2，允许被 SysTick(15) 打断 ---- */
    NVIC_SetPriority(TIM6_DAC_IRQn, 2);
    NVIC_EnableIRQ(TIM6_DAC_IRQn);

    /* ---- 启动计数器 ---- */
    TIM6->CR1 |= TIM_CR1_CEN;

    /* ---- PID 参数初始化 ---- */
    /* 暂无编码器：kp=1, ki=0, kd=0 → 输出直接等于 setpoint（电位器值）
     * 积分限幅随 ki=0 无效，设为 out_max 的 50% 供后续使用 */
    PID_Init(&motor_pid,
             /*kp*/1.0f, /*ki*/0.0f, /*kd*/0.0f,
             /*out_min*/0.0f, /*out_max*/4095.0f,
             /*integral_max*/2048.0f);
}

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
   while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/* USER CODE BEGIN 1 */

/* =============================================================================
 * TIM6 更新中断 —— 1kHz PID 控制环
 *
 * 执行时间估算（5.25MHz SPI，21MHz ADC）：
 *   ADC 转换 ≈ 4.6μs，SPI 2字节 ≈ 3μs，其余开销 < 1μs → 共约 9μs
 *   占 1ms 周期的 0.9%，完全可接受。
 * ============================================================================= */
void TIM6_DAC_IRQHandler(void)
{
    if (TIM6->SR & TIM_SR_UIF) {
        TIM6->SR &= ~TIM_SR_UIF;    /* 清除更新中断标志（必须第一时间清） */

        /* 1. 读取期望值（电位器，0~4095） */
        uint16_t setpoint = ADC1_Read();

        /* 2. PID 计算
         *    feedback = 0.0f（占位，编码器接入后替换此参数）
         *    当前 kp=1, ki=0, kd=0 时：output = 1*(setpoint-0) = setpoint（直通）
         */
        float duty_f = PID_Calc(&motor_pid, (float)setpoint, 0.0f);
        uint16_t duty = (uint16_t)duty_f;

        /* 3. 通过 SPI2 发给 FPGA（2字节，12bit 占空比） */
        uint8_t hi = (duty >> 8) & 0x0F;
        uint8_t lo =  duty       & 0xFF;

        FPGA_CS_LOW();
        SPI2_ReadWriteByte(hi);
        SPI2_ReadWriteByte(lo);
        FPGA_CS_HIGH();

        /* 4. 更新全局变量，供 main 循环读取打印 */
        g_pid_duty = duty;
    }
}

/* USER CODE END 1 */
